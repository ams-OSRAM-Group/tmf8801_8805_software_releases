#!/bin/bash
# Linux commands
#
# make sure all the following files are in the current directory
# libtof.so  main_app.hex  tmf8701.ko  tof_main  tof8701-overlay.dtbo  tofguimodule.so
# this script run with su privilege.
#
# if user pass in k1 it's a encrypted device.
if [ $# -eq 0 ]
then
  echo "Copying the hex file..."
  cp main_app_3v1.hex /lib/firmware/tof8701_firmware.bin
else
  # Future todo check user input to copy different encrypted key file
  # currently only support k1
  # reset file system to original state. remove all files from 8701 8801
  ./reset.sh
  echo "Copying the encrypted hex file..."
  cp main_app_3v1_k1.hex /lib/firmware/tof8701_firmware.bin
fi
#
if grep -Fxq "dtoverlay=tof8701-overlay" /boot/config.txt
then
    echo "No need to modify /boot/config.txt"
else
    echo "Append dtoverlay=tof8701-overlay to /boot/config.txt"
    echo "dtoverlay=tof8701-overlay" >> /boot/config.txt
fi
rm -f /usr/local/lib/libtof.so
cp tof8701-overlay.dtbo /boot/overlays/
cp libtof.so /usr/lib/
cp tofguimodule.so /opt/USBSensorBridgeRuntime/modules/
cp tmf8701.ko /opt/USBSensorBridgeRuntime/modules/
echo "modules/tmf8701.ko" > /opt/USBSensorBridgeRuntime/config/default_driver.config
echo "modules/tofguimodule.so" > /opt/USBSensorBridgeRuntime/config/default_module.config
#
# copy the spad_mask.csv to /home/pi
cp spad_mask.csv /home/pi/
# copy tofgenapp to /home/pi/bin
if [ !  -d /home/pi/bin ]
then
    mkdir -p /home/pi/bin
fi
#
cp tofgenapp /home/pi/bin/
cp tofdatacollect /home/pi/bin/
cp tofalgstate /home/pi/bin/
chmod 755 -R /home/pi/bin
#
# Remove the factory calibrate file
rm -f /lib/firmware/tof8701_fac_calib.bin

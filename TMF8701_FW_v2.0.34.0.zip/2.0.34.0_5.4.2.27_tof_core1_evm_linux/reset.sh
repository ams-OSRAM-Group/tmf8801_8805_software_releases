#!/bin/bash
# Linux commands
#
# make sure all the following files are in the current directory
# reset.sh config.txt
# this script run with su privilege.
# this script remove all 8701 and 8801 files
#
echo "Removing all 8701 8801 files ..."
rm -f /lib/firmware/tof8701_firmware.bin
rm -f /lib/firmware/tof8801_firmware.bin
cp -f config.txt /boot/config.txt
rm -f /boot/overlays/tof8701-overlay.dtbo
rm -f /boot/overlays/tof8801-overlay.dtbo
rm -f /usr/lib/libtof.so
rm -f /opt/USBSensorBridgeRuntime/modules/tofguimodule.so
rm -f /opt/USBSensorBridgeRuntime/modules/tmf8701.ko
rm -f /opt/USBSensorBridgeRuntime/modules/tmf8801.ko

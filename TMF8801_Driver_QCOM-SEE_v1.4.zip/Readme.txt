/*Readme file for TMF8801 QComm SEE driver 1.x */

This driver is developed on QualComm Snapdragon_SCEP.GEN.6.0-00011-1 platform. It works on Open-Q 845 development kits.

Steps to use this driver

1:  Unzip file 3.x.x.x_x.x.x.x_tof_core3_evm_linux.zip to local drive.
2:  Unzip file aos_tmf8801_qc_see_6.0_src_v1.x.zip to local drive.
3:  From unzipped 3.x.x.x_x.x.x.x_tof_core3_evm_linux folder, copy tmf8801_0_firmware.json to QCOMM development platform folder
    slpi_proc\ssc\tools\see_hal_libs\registry_files.
4:  From unzipped aos_tmf8801_qc_see_6.0_src_v1.x\registry folder, copy sdm845_tmf8801.json and tmf8801.json file to QCOMM development 
    platform folder slpi_proc\ssc\tools\see_hal_libs\registry_files.
5:  Inside slpi_proc\ssc\tools\see_hal_libs\registry_files, open config_list.txt, put these 3 file names in the list
    sdm845_tmf8801.json,
    tmf8801.json,
    tmf8801_0_firmware.json
6:  Create a folder with name aos_tmf8801_qc_see inside folder slpi_proc\ssc\sensors.
7:  From unzipped aos_tmf8801_qc_see_6.0_src_v1.x folder, copy all 3 folders, build, hexagon, and registry to the aos_tmf8801_qc_see
    folder you just created in step 6.
8:  Build the driver with the QCOMM platform.
9:  Download the driver to Open-Q 845 board.
10: Download the registry files to Open-Q 845 board.
11: Reboot the board.


Enable / Disable compile options while building the driver

    Compile options can be modified in sns_tmf8801.scons file.
    
1:  To disable logging, these 3 compile options need to be commented out:
    DENABLE_DEBUG
    DAMS_DEBUG_FORCE_PRINT
    DAMS_DEV_DEBUG_ENABLE
    
    In the final version running on customer's board, logging needs to be disabled.
    
2:  tmf8801_island_enable can be set to True if needed.
    
    



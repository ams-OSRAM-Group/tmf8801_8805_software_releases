See documentation BareMetal_Compile_Execute_1v0.pdf for howto compile and execute the driver on the Raspberry PI (part of EVM)


To run the mcu_tmf8805 bare metal driver on the TMF8805 EVM you must first remove the linux kernel driver from the raspberry pi EVM and then start the program. To do so use:
 
1.	Copy the bare metal linux driver to the raspberry - use a program to support scp like WinSCP (login information see (2.)) - copy aos_tmf8805_mcu_driver_bin_3.0.18.0_1.6.zip zipfile to Raspberry
2.	ssh into raspberry PI (e.g. through a terminal program supporting ssh like PuTTY or using Cygwin)
	ssh pi@169.254.0.2
	# IP address: 169.254.0.2
	# User: pi
	# Password: raspberry
3.	Unzip zipfiles
	unzip aos_tmf8805_mcu_driver_bin_3.0.18.0_1.6.zip
4.	comment out the tof device tree from /boot/config.txt
	sudo nano  /boot/config.txt
	a.	dtoverlay=tof8801-overlay --> #dtoverlay=tof8801-overlay
5.	remove the tof kernel module from the software framework
	sudo rm /opt/USBSensorBridgeRuntime/modules/tmf8?01.ko
6.	add ‘i2c-dev’ to /etc/modules
	sudo nano /etc/modules
	a.	Check for a line with "i2c-dev"
7.	sync && reboot
	sudo reboot now
8.	After the raspberry rebooted, log into the raspberry again (same as (2.))
9.	Change to the directory where the binary of bare metal linux driver is installed from (1.)
	cd aos_tmf8805_mcu_driver_bin_3.0.18.0_1.6/bin/
10.	Run ./mcu_tmf8805 –h  to display the help screen for running the bare metal driver
	sudo ./mcu_tmf8805 -h
11.	Generate calibration file (no object in front of EVM within 40cm)
	sudo ./mcu_tmf8805 -z calib.txt
12.	Run measurement
	sudo ./mcu_tmf8805 -c calib.txt
 
 
To restore the functionality of the EVM use following commands
ssh into Raspberry
# see command (2.) from above
cd  3.0.18.0_5.3.3.15_tof_core3_evm_linux/
# or later version
sudo ./install_3v3.sh k2
sudo reboot now


(c) ams AG September / 2020 / ptr

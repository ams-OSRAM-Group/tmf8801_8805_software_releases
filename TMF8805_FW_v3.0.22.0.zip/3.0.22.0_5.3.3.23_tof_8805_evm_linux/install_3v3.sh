#!/bin/bash
# Linux commands
#
# make sure all the following files are in the current directory
# libtof.so  main_app_3v3_k2.hex main_app_3v3_k3.hex  tmf8805.ko  tof_main  tof8805-overlay.dtbo  tofguimodule.so
# this script run with su privilege.
#
./reset.sh
echo "Copying the encrypted k3 hex file..."
cp main_app_3v3_k3.hex /lib/firmware/tof8805_firmware.bin
#
if grep -Fxq "dtoverlay=tof8805-overlay" /boot/config.txt
then
    echo "No need to modify /boot/config.txt"
else
    echo "Append dtoverlay=tof8805-overlay to /boot/config.txt"
    echo "dtoverlay=tof8805-overlay" >> /boot/config.txt
fi
rm -f /usr/local/lib/libtof.so
cp tof8805-overlay.dtbo /boot/overlays/
cp libtof.so /usr/lib/
cp tofguimodule.so /opt/USBSensorBridgeRuntime/modules/
cp tmf8805.ko /opt/USBSensorBridgeRuntime/modules/
echo "modules/tmf8805.ko" > /opt/USBSensorBridgeRuntime/config/default_driver.config
echo "modules/tofguimodule.so" > /opt/USBSensorBridgeRuntime/config/default_module.config
#
# copy the spad_mask.csv to /home/pi
cp spad_mask.csv /home/pi/
# copy tofgenapp to /home/pi/bin
if [ !  -d /home/pi/bin ]
then
    mkdir -p /home/pi/bin
fi
#
cp tofgenapp /home/pi/bin/
cp tofdatacollect /home/pi/bin/
cp tofalgstate /home/pi/bin/
chmod 755 -R /home/pi/bin
#
# Remove the factory calibrate file
rm -f /lib/firmware/tof8805_fac_calib.bin
